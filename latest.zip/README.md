# 2016_IMY320_YoCo

## Team Members
| Full Name					| Student No. |
| ----------------- | ----------- |
| Patience Mtsweni  | 11116774	  |
| Mpedi Mello				| 11210754    |
| Priscilla Madigoe | 13049128    |

### Introduction
This project forms part of IMY320 (a 3rd year course at the University of Pretoria). It is aimed at creating an admin system for a Non-Profit Organisation (NPO). As members increase for the NPO, some tasks such as managing members, planning events, compiling and sending out newsletters, and event invites become more and more cumbersome and redundant. So it suffices to have a more efficient method of doing all these tasks to keep up with the growth of the NPO.


